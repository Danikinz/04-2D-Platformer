# 2D-Platformer-Character

A somewhat-generic character (including animations and state machine) appropriate for a 2D platformer built in Godot. Includes test level.

## Implementation
Built using Godot 3.2.3

The player sprite is adaptated from [MV Platformer Male](https://opengameart.org/content/mv-platformer-male-32x64) by MoikMellah. CC0 Licensed.

## References
None

## Future Development
None

## Extra Credit
None

## Created by 
Jason Francis